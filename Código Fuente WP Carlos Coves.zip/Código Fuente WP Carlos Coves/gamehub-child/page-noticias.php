<?php
/* Plantilla de la página de Noticias */
get_header();

$noticias = new WP_Query(array(
    'category_name'  => 'noticias',
    'posts_per_page' => 12,
));
?>

<main class="gh-noticias" style="max-width:1200px; margin:0 auto; padding:2rem;">

  <nav class="gh-nav" style="margin-bottom:2rem;">
    <a href="<?php echo home_url('/noticias'); ?>" class="activo">Noticias</a>
    <a href="<?php echo home_url('/ranking'); ?>">Ranking</a>
    <a href="<?php echo home_url('/videojuego'); ?>">Catalogo</a>
    <a href="<?php echo home_url('/blog-comunidad'); ?>">Blog</a>
  </nav>

  <h1>Noticias Destacadas</h1>

  <?php if ($noticias->have_posts()) : ?>
    <div class="gh-grid-2">

      <?php while ($noticias->have_posts()) : $noticias->the_post(); ?>
        <article style="display:flex; gap:1rem;">
          <div style="flex:0 0 120px;">
            <?php if (has_post_thumbnail()) {
                the_post_thumbnail('medium', array('style' => 'width:120px; height:auto;'));
            } else {
                echo '<div style="width:120px; height:120px; background:#ddd; display:flex; align-items:center; justify-content:center; font-size:0.8rem;">NO IMAGE</div>';
            } ?>
          </div>
          <div>
            <h2 style="margin:0; font-size:1.2rem;">
              <a href="<?php the_permalink(); ?>" style="text-decoration:none; color:var(--gh-texto);"><?php the_title(); ?></a>
            </h2>
            <p style="font-size:0.85rem; color:#555; margin:0.3rem 0;">
              Categoría: [Noticia] · <?php echo get_the_date(); ?>
            </p>
            <p style="font-size:0.9rem; margin:0;">
              <?php echo wp_trim_words(get_the_excerpt(), 25); ?>
            </p>
            <a href="<?php the_permalink(); ?>" style="font-size:0.85rem; color:var(--gh-naranja);">Leer más →</a>
          </div>
        </article>
      <?php endwhile; ?>

    </div>
    <?php wp_reset_postdata(); ?>
  <?php else : ?>
    <p>No hay noticias publicadas todavía.</p>
  <?php endif; ?>

</main>

<?php get_footer(); ?>