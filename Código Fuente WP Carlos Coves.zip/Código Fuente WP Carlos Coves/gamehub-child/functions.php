<?php
// Cargar el estilo del tema padre y luego el del hijo
function gamehub_estilos() {
    wp_enqueue_style('padre', get_template_directory_uri() . '/style.css');
    wp_enqueue_style('hijo', get_stylesheet_uri(), array('padre'));
}
add_action('wp_enqueue_scripts', 'gamehub_estilos');

// Traducir los nombres de los roles (pendiente del Bloque 4)
function gamehub_traducir_roles() {
    global $wp_roles;
    $wp_roles->roles['editor']['name'] = 'Redactor';
    $wp_roles->role_names['editor'] = 'Redactor';
    $wp_roles->roles['author']['name'] = 'Colaborador';
    $wp_roles->role_names['author'] = 'Colaborador';
    $wp_roles->roles['subscriber']['name'] = 'Suscriptor';
    $wp_roles->role_names['subscriber'] = 'Suscriptor';
}
add_action('init', 'gamehub_traducir_roles');

// Mostrar campos ACF del videojuego al final de su contenido
function gamehub_mostrar_datos_videojuego($content) {
    if (is_singular('videojuego') && function_exists('get_field')) {
        $notaP = get_field('nota_prensa');
        $notaC = get_field('nota_comunidad');
        $dev   = get_field('desarrollador');
        $genero = get_field('genero');
        $fecha = get_field('fecha_lanzamiento');

        $extra  = '<div class="gh-card gh-notas">';
        $extra .= '<p><strong>Nota prensa:</strong> ' . esc_html($notaP) . '</p>';
        $extra .= '<p><strong>Nota comunidad:</strong> ' . esc_html($notaC) . '</p>';
        $extra .= '<p><strong>Desarrollador:</strong> ' . esc_html($dev) . '</p>';
        $extra .= '<p><strong>Género:</strong> ' . esc_html($genero) . '</p>';
        $extra .= '<p><strong>Lanzamiento:</strong> ' . esc_html($fecha) . '</p>';
        $extra .= '</div>';
        return $content . $extra;
    }
    return $content;
}
add_filter('the_content', 'gamehub_mostrar_datos_videojuego');

// Mostrar campos ACF del evento al final de su contenido
function gamehub_mostrar_datos_evento($content) {
    if (is_singular('evento') && function_exists('get_field')) {
        $fecha = get_field('fecha_evento');
        $lugar = get_field('lugar');
        $tipo  = get_field('tipo_evento');
        $enlace = get_field('enlace');

        $extra  = '<div class="gh-card gh-notas">';
        $extra .= '<p><strong>Fecha:</strong> ' . esc_html($fecha) . '</p>';
        $extra .= '<p><strong>Lugar:</strong> ' . esc_html($lugar) . '</p>';
        $extra .= '<p><strong>Tipo:</strong> ' . esc_html($tipo) . '</p>';
        if ($enlace) {
            $extra .= '<p><a href="' . esc_url($enlace) . '">Más información</a></p>';
        }
        $extra .= '</div>';
        return $content . $extra;
    }
    return $content;
}
add_filter('the_content', 'gamehub_mostrar_datos_evento');
// Redirigir tras el login según el rol (CU-02)
function gamehub_redireccion_login($redirect_to, $request, $user) {
    if (isset($user->roles) && is_array($user->roles)) {
        // Suscriptores van a la home; el resto al panel
        if (in_array('subscriber', $user->roles)) {
            return home_url();
        } else {
            return admin_url(); // Admin, Redactor, Colaborador van al panel
        }
    }
    return $redirect_to;
}
add_filter('login_redirect', 'gamehub_redireccion_login', 10, 3);
// Ocultar elementos del menú del panel a quien no es administrador
function gamehub_limpiar_menu_admin() {
    if (!current_user_can('manage_options')) { // si NO es admin
        remove_menu_page('tools.php');         // Herramientas
        remove_menu_page('edit-comments.php');  // (si no quieres que moderen)
    }
}
add_action('admin_menu', 'gamehub_limpiar_menu_admin');
// Widget de bienvenida personalizado en el dashboard
function gamehub_widget_bienvenida() {
    wp_add_dashboard_widget('gamehub_bienvenida', 'Bienvenido a GameHub', function() {
        $usuario = wp_get_current_user();
        echo '<p>Hola, <strong>' . esc_html($usuario->display_name) . '</strong>.</p>';
        echo '<p>Tu rol: <strong>' . esc_html(translate_user_role(ucfirst($usuario->roles[0]))) . '</strong></p>';
        echo '<p>Desde aquí puedes gestionar tu contenido y perfil.</p>';
    });
}
add_action('wp_dashboard_setup', 'gamehub_widget_bienvenida');
// Asegurar la etiqueta viewport para responsive (RF-11)
function gamehub_viewport() {
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">' . "\n";
}
add_action('wp_head', 'gamehub_viewport', 1);