<?php get_header(); ?>

<main class="gh-catalogo" style="max-width:1200px; margin:0 auto; padding:2rem;">
  <nav class="gh-nav" style="margin-bottom:2rem;">
    <a href="<?php echo home_url('/noticias'); ?>">Noticias</a>
    <a href="<?php echo home_url('/ranking'); ?>">Ranking</a>
    <a href="<?php echo home_url('/videojuego'); ?>" class="activo">Catalogo</a>
    <a href="<?php echo home_url('/blog-comunidad'); ?>" ...>Blog</a>
  </nav>

  <?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>

      <article class="gh-card gh-fila">
        <div style="flex:0 0 160px;">
          <?php if (has_post_thumbnail()) {
              the_post_thumbnail('medium');
          } else {
              echo '<div style="width:160px;height:160px;background:#ddd;display:flex;align-items:center;justify-content:center;">NO IMAGE</div>';
          } ?>
        </div>

        <div style="flex:1;">
          <h2 style="margin-top:0;"><?php the_title(); ?></h2>
          <div class="gh-notas">
            <p><strong>Nota prensa:</strong> <?php echo esc_html(get_field('nota_prensa')); ?></p>
            <p><strong>Nota comunidad:</strong> <?php echo esc_html(get_field('nota_comunidad')); ?></p>
            <p><strong>Género:</strong> <?php echo esc_html(get_field('genero')); ?></p>
            <p><strong>Desarrollador:</strong> <?php echo esc_html(get_field('desarrollador')); ?></p>
          </div>
          <p><?php echo esc_html(get_the_excerpt()); ?></p>
          <a href="<?php the_permalink(); ?>">Ver ficha completa →</a>
        </div>
      </article>

    <?php endwhile; ?>
  <?php else : ?>
    <p>No hay videojuegos en el catálogo todavía.</p>
  <?php endif; ?>
</main>

<?php get_footer(); ?>