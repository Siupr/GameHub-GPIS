<?php
/* Plantilla de la portada de GameHub */
get_header();

?>
<header class="gh-topbar">
  <a href="<?php echo home_url('/'); ?>" class="gh-logo">GAMEHUB</a>
  <div>
    <input type="text" placeholder="Buscar..." style="padding:0.5rem 1rem; border-radius:20px; border:none; margin-right:1rem;">
    <a href="<?php echo wp_login_url(); ?>" style="background:var(--gh-naranja); color:#fff; padding:0.6rem 1.2rem; border-radius:20px;">Registro/login</a>
  </div>
</header>
<main class="gh-home" style="max-width:1200px; margin:0 auto; padding:2rem;">

  <nav class="gh-nav" style="margin-bottom:2rem;">
    <a href="<?php echo home_url('/noticias'); ?>">Noticias</a>
    <a href="<?php echo home_url('/ranking'); ?>">Ranking</a>
    <a href="<?php echo home_url('/videojuego'); ?>">Catalogo</a>
    <a href="<?php echo home_url('/blog-comunidad'); ?>">Blog</a>
  </nav>

  <!-- ZONA 1: Destacado -->
  <?php
  $destacada = new WP_Query(array(
      'category_name'  => 'noticias',
      'posts_per_page' => 1,
  ));
  if ($destacada->have_posts()) :
    while ($destacada->have_posts()) : $destacada->the_post(); ?>
      <section class="gh-card" style="display:flex; gap:2rem; align-items:center; margin-bottom:2rem;">
        <div style="flex:0 0 45%;">
          <?php if (has_post_thumbnail()) {
              the_post_thumbnail('large', array('style' => 'width:100%; height:auto;'));
          } else {
              echo '<div style="width:100%; height:300px; background:#ddd; display:flex; align-items:center; justify-content:center;">NO IMAGE</div>';
          } ?>
        </div>
        <div style="flex:1;">
          <p style="color:#555; margin:0;">Noticia Destacada</p>
          <h1 style="margin:0.5rem 0;"><?php the_title(); ?></h1>
          <p><?php echo esc_html(get_the_excerpt()); ?></p>
          <a href="<?php the_permalink(); ?>" style="color:var(--gh-naranja); font-weight:bold;">Leer más →</a>
        </div>
      </section>
    <?php endwhile; wp_reset_postdata();
  endif; ?>

  <!-- ZONA 2 y 3: Últimas Noticias + Top Ranking -->
  <div class="gh-fila">

    <!-- Últimas Noticias -->
    <section class="gh-card" style="flex:2;">
      <h2 style="margin-top:0;">Últimas Noticias</h2>
      <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem;">
        <?php
        $noticias = new WP_Query(array(
            'category_name'  => 'noticias',
            'posts_per_page' => 4,
            'offset'         => 1,   // saltamos la destacada
        ));
        if ($noticias->have_posts()) :
          while ($noticias->have_posts()) : $noticias->the_post(); ?>
            <article style="display:flex; gap:0.8rem;">
              <div style="flex:0 0 80px;">
                <?php if (has_post_thumbnail()) {
                    the_post_thumbnail('thumbnail', array('style' => 'width:80px; height:auto;'));
                } else {
                    echo '<div style="width:80px; height:80px; background:#ddd; display:flex; align-items:center; justify-content:center; font-size:0.7rem;">NO IMAGE</div>';
                } ?>
              </div>
              <div>
                <h3 style="margin:0; font-size:1rem;"><a href="<?php the_permalink(); ?>" style="text-decoration:none; color:var(--gh-texto);"><?php the_title(); ?></a></h3>
                <p style="font-size:0.8rem; color:#555; margin:0.3rem 0;"><?php echo get_the_date(); ?></p>
                <p style="font-size:0.85rem; margin:0;"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
              </div>
            </article>
          <?php endwhile; wp_reset_postdata();
        else : ?>
          <p>No hay noticias todavía.</p>
        <?php endif; ?>
      </div>
    </section>

    <!-- Top Ranking lateral -->
    <aside class="gh-card" style="flex:1;">
      <h2 style="margin-top:0;">Top Ranking</h2>
      <?php
      $top = new WP_Query(array(
          'post_type'      => 'videojuego',
          'posts_per_page' => 3,
          'meta_key'       => 'nota_prensa',
          'orderby'        => 'meta_value_num',
          'order'          => 'DESC',
      ));
      if ($top->have_posts()) :
        while ($top->have_posts()) : $top->the_post(); ?>
          <article style="display:flex; gap:0.8rem; margin-bottom:1rem;">
            <div style="flex:0 0 70px;">
              <?php if (has_post_thumbnail()) {
                  the_post_thumbnail('thumbnail', array('style' => 'width:70px; height:auto;'));
              } else {
                  echo '<div style="width:70px; height:70px; background:#ddd; display:flex; align-items:center; justify-content:center; font-size:0.7rem;">NO IMAGE</div>';
              } ?>
            </div>
            <div class="gh-notas" style="font-size:0.8rem;">
              <h3 style="margin:0; font-size:0.95rem;"><?php the_title(); ?></h3>
              <p style="margin:0.2rem 0;"><strong>Prensa:</strong> <?php echo esc_html(get_field('nota_prensa')); ?></p>
              <p style="margin:0;"><strong>Jugadores:</strong> <?php echo esc_html(get_field('nota_comunidad')); ?></p>
            </div>
          </article>
        <?php endwhile; wp_reset_postdata();
      else : ?>
        <p>No hay ranking todavía.</p>
      <?php endif; ?>
    </aside>

  </div>

</main>

<?php get_footer(); ?>