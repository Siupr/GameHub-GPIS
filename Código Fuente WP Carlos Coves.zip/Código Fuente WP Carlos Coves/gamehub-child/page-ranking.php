<?php
/* Template Name: Ranking */
get_header();


// Consulta personalizada: videojuegos ordenados por nota de prensa (desc)
$args = array(
    'post_type'      => 'videojuego',
    'posts_per_page' => 10,
    'meta_key'       => 'nota_prensa',
    'orderby'        => 'meta_value_num',
    'order'          => 'DESC',
);
$ranking = new WP_Query($args);
$posicion = 1;
?>

<main class="gh-ranking" style="max-width:1200px; margin:0 auto; padding:2rem;">
  <nav class="gh-nav" style="margin-bottom:2rem;">
    <a href="<?php echo home_url('/noticias'); ?>">Noticias</a>
    <a href="<?php echo home_url('/ranking'); ?>" class="activo">Ranking</a>
    <a href="<?php echo home_url('/videojuego'); ?>">Catalogo</a>
    <a href="<?php echo home_url('/blog-comunidad'); ?>" ...>Blog</a>
  </nav>

  <h1>Top Ranking</h1>

  <?php if ($ranking->have_posts()) : ?>
    <?php while ($ranking->have_posts()) : $ranking->the_post(); ?>

      <article class="gh-card gh-fila">
        <div style="font-size:2.5rem; font-weight:bold; flex:0 0 50px;">
          <?php echo $posicion; ?>.
        </div>

        <div style="flex:0 0 140px;">
          <?php if (has_post_thumbnail()) {
              the_post_thumbnail('medium');
          } else {
              echo '<div style="width:140px;height:140px;background:#ddd;display:flex;align-items:center;justify-content:center;">NO IMAGE</div>';
          } ?>
          <div class="gh-notas" style="margin-top:0.5rem;">
            <p><strong>Nota prensa:</strong> <?php echo esc_html(get_field('nota_prensa')); ?></p>
            <p><strong>Nota jugadores:</strong> <?php echo esc_html(get_field('nota_comunidad')); ?></p>
          </div>
        </div>

        <div style="flex:1; border-left:2px solid var(--gh-verde-oscuro); padding-left:1.5rem;">
          <h2 style="margin-top:0;"><?php the_title(); ?></h2>
          <p><?php echo esc_html(get_the_excerpt()); ?></p>
        </div>
      </article>

      <?php $posicion++; ?>
    <?php endwhile; ?>
    <?php wp_reset_postdata(); ?>
  <?php else : ?>
    <p>No hay videojuegos en el ranking todavía.</p>
  <?php endif; ?>
</main>

<?php get_footer(); ?>