<?php get_header(); ?>

<main style="max-width:800px; margin:0 auto; padding:2rem;">

  <?php while (have_posts()) : the_post(); ?>

    <article class="gh-card">
      <h1><?php the_title(); ?></h1>
      <p style="color:#555;">
        Por <?php the_author(); ?> · <?php echo get_the_date(); ?>
      </p>
      <div><?php the_content(); ?></div>
    </article>

    <section id="comentarios" style="margin-top:2rem;">
      <?php
        // Carga el sistema de comentarios de WordPress
        if (comments_open() || get_comments_number()) {
            comments_template();
        }
      ?>
    </section>

  <?php endwhile; ?>

</main>

<?php get_footer(); ?>