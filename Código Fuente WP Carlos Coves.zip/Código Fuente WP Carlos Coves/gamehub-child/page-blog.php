<?php
/* Plantilla para la página de Blog */
get_header();

$args = array(
    'category_name'  => 'blog',   // el slug de tu categoría "Blog de opinión"
    'posts_per_page' => 10,
);
$blog = new WP_Query($args);
?>

<main class="gh-blog" style="max-width:1000px; margin:0 auto; padding:2rem;">
  <nav class="gh-nav" style="margin-bottom:2rem;">
    <a href="<?php echo home_url('/noticias'); ?>">Noticias</a>
    <a href="<?php echo home_url('/ranking'); ?>">Ranking</a>
    <a href="<?php echo home_url('/videojuego'); ?>">Catalogo</a>
    <a href="<?php echo home_url('/blog-comunidad'); ?>" ...>Blog</a>
  </nav>

  <h1>Blog de la Comunidad</h1>

  <?php if ($blog->have_posts()) : ?>
    <?php while ($blog->have_posts()) : $blog->the_post(); ?>

      <article class="gh-card">
        <h2 style="margin-top:0;"><?php the_title(); ?></h2>
        <div><?php the_content(); ?></div>
        <div style="margin-top:1rem;">
          <a href="<?php the_permalink(); ?>#comentarios"
             style="background:var(--gh-naranja); color:#fff; padding:0.5rem 1.2rem; border-radius:20px; text-decoration:none;">
            Comentar (<?php echo get_comments_number(); ?>)
          </a>
        </div>
      </article>

    <?php endwhile; ?>
    <?php wp_reset_postdata(); ?>
  <?php else : ?>
    <p>No hay publicaciones en el blog todavía.</p>
  <?php endif; ?>
</main>

<?php get_footer(); ?>